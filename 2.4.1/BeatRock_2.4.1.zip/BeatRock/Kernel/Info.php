<?php
#####################################################
## 					 BeatRock				   	   ##
#####################################################
## Framework avanzado de procesamiento para PHP.   ##
#####################################################
## InfoSmart � 2012 Todos los derechos reservados. ##
## http://www.infosmart.mx/						   ##
#####################################################
## http://beatrock.infosmart.mx/				   ##
#####################################################

// Acci�n ilegal.
if(!defined("BEATROCK"))
	exit;

## ------------------------------------------------------------
##           Informaci�n de versi�n de BeatRock.
## ------------------------------------------------------------
## Informaci�n acerca de la versi�n del Kernel y detalles
## acerca de su creaci�n.
## ------------------------------------------------------------

## ---------------------------------------------------------
## Nombre del Kernel.
## Si ha hecho modificaciones, cree su propio "Code Name".
## ---------------------------------------------------------

$Info['name'] = "BeatRock";
$Info['code'] = "Info";

## ---------------------------------------------------------
## Versi�n del Kernel.
## ---------------------------------------------------------

$Info['mayor'] = "2";
$Info['minor'] = "4";
$Info['micro'] = "1";
$Info['revision'] = "006";

## ---------------------------------------------------------
## Fase del desarrollo.
## Alpha -> BETA -> PP -> RC -> Producci�n
## ---------------------------------------------------------

$Info['fase'] = "Stable";
$Info['fase_ver'] = "1";

## ---------------------------------------------------------
## Fecha de creaci�n.
## ---------------------------------------------------------

$Info['date'] = "23.marzo.2012";
$Info['date_hour'] = "03:40 AM";

## ---------------------------------------------------------
## Nombres.
## ---------------------------------------------------------

$Info['version'] = "$Info[mayor].$Info[minor].$Info[micro]";
$Info['version.name'] = "$Info[name] v$Info[version]";
$Info['version.code'] = "$Info[name] \"$Info[code]\" v$Info[version]";
$Info['version.revision'] = "$Info[version] Revisi�n:  $Info[revision]";
$Info['version.date'] = "$Info[version] - $Info[date] $Info[date_hour]";
$Info['version.fase'] = "$Info[fase] $Info[fase_ver]";
$Info['version.full'] = $Info['version.code'] . " $Info[fase]$Info[fase_ver] Revisi�n: $Info[revision] - $Info[date] $Info[date_hour]";
?>