<?php
#####################################################
## 					 BeatRock				   	   ##
#####################################################
## Framework avanzado de procesamiento para PHP.   ##
#####################################################
## InfoSmart � 2012 Todos los derechos reservados. ##
## http://www.infosmart.mx/						   ##
#####################################################
## http://beatrock.infosmart.mx/				   ##
#####################################################

require('Init.php');

# -------------------------------------------------
# [id] = Plantilla a usar.
# -------------------------------------------------

$page['id'] = "index";

/*

# -------------------------------------------------
# Array [id] = Plantillas a usar. (En orden)
# -------------------------------------------------

$page['id'] = Array(
	"index", 
	"about"
);

# -------------------------------------------------
# [folder] = Folder de plantillas a usar.
# -------------------------------------------------

$page['folder'] = "/folder_template/";

# -------------------------------------------------
# [name] = Nombre de la p�gina.
# Ejemplo: Mi sitio web - (Nombre)
# -------------------------------------------------

$page['name'] = "P�gina";

# -------------------------------------------------
# [site_name] = Nombre de todo el sitio.
# Ejemplo: (Nombre)
# -------------------------------------------------

$page['site_name'] = "Nombre del sitio";

# -------------------------------------------------
# Bool [header] = Uso de cabecera.
# -------------------------------------------------

$page['header'] = false;

# -------------------------------------------------
# Bool [footer] = Uso del pie de p�gina.
# -------------------------------------------------

$page['footer'] = false;

# -------------------------------------------------
# [subheader] = Uso de sub-cabecera.
# Definelo como "none" si no deseas ninguno.
# -------------------------------------------------

$page['subheader'] = "none";

# -------------------------------------------------
# [subfooter] = Uso de sub pie de p�gina.
# Definelo como "none" si no deseas ninguno.
# -------------------------------------------------

$page['subfooter'] = "none";

# -------------------------------------------------
# [lang] = Obligar uso de idioma en la p�gina.
# -------------------------------------------------

$page['lang'] = "en";

# -------------------------------------------------
# Bool [smart_translate] = Traducci�n inteligente.
# -------------------------------------------------

$page['smart_translate'] = true;

# -------------------------------------------------
# [lang_param] = Cambiar el parametro de traducci�n.
# -------------------------------------------------

$page['lang_param'] = "||";

# -------------------------------------------------
# Bool [compress] = Compresi�n HTML.
# -------------------------------------------------

$page['compress'] = false;
*/

?>