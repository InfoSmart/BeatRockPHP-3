<?php
require('Init.php');

# -------------------------------------------------
# Para m�s informaci�n visite 'index.details.php'
# -------------------------------------------------

$page['id'] = "index";
$page['name'] = "Inicio";
?>